from tqdm import tqdm
import argparse
import math
import os
import shutil
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.distributed as dist
import torch.optim
import apex
from apex.parallel.LARC import LARC
from scipy.sparse import csr_matrix
import torch.multiprocessing as mp

from src.utils import (
    initialize_exp,
    restart_from_checkpoint,
    fix_random_seeds,
    AverageMeter,
    init_distributed_mode,
    concat_all_gather
)
from src.multicropdataset import MultiCropDataset
import src.resnet50 as resnet_models
from src.SwinTrans_multicrop import SwinTransformer
from src.two_stream_network import TwoStreamNet
from src.optimizer import build_opt_swinT


parser = argparse.ArgumentParser(description="Implementation of SMoG")

#########################
#### data parameters ####
#########################
parser.add_argument("--data_path", type=str, default="/path/to/imagenet",
                    help="path to dataset repository")
parser.add_argument("--nmb_crops", type=int, default=[4, 4], nargs="+",
                    help="list of number of crops (example: [4, 4])")
parser.add_argument("--size_crops", type=int, default=[224, 96], nargs="+",
                    help="crops resolutions (example: [224, 96])")
parser.add_argument("--min_scale_crops", type=float, default=[0.2, 0.05], nargs="+",
                    help="argument in RandomResizedCrop (example: [0.2, 0.05])")
parser.add_argument("--max_scale_crops", type=float, default=[1.0, 0.2], nargs="+",
                    help="argument in RandomResizedCrop (example: [1., 0.2])")

#########################
## SMoG specific params #
#########################
parser.add_argument("--crops_for_assign", type=int, nargs="+", default=[0, 1],
                    help="list of crops id used for computing assignments")
parser.add_argument("--crops_for_q", type=int, nargs="+", default=[2, 3],
                    help="list of crops id used for computing assignments")
parser.add_argument("--temperature", default=0.1, type=float,
                    help="temperature parameter in training loss")
parser.add_argument("--feat_dim", default=128, type=int,
                    help="feature dimension")
parser.add_argument("--nmb_prototypes", default=[3000, 3000, 3000], type=int, nargs="+",
                    help="number of prototypes - it can be multihead")
parser.add_argument("--K_momentum", type=float, default=0.999,
                    help="momentum of the key encoder")
parser.add_argument("--C_momentum", type=float, default=1.0,
                    help="momentum of the centroids")
parser.add_argument("--C_momentum_final", type=float, default=0.9,
                    help="final momentum of the centroids")
parser.add_argument("--with_predictor", default=True, action="store_true",
                    help="whether have predictor in q_encoder")
parser.add_argument("--reset_k_encoder", default=True, action="store_true",
                    help="whether reset k_encoder for every epoch")
parser.add_argument("--linear_C_momentum", default=True, action="store_true",
                    help="whether linear decrease C_momentum")
parser.add_argument("--byolAug", default=False, action="store_true",
                    help="whether adopt augmentation of byol")
parser.add_argument("--multi_forward", default=False, action="store_true",
                    help="whether multiple forward & one backward")

#########################
#### optim parameters ###
#########################
parser.add_argument("--epochs", default=100, type=int,
                    help="number of total epochs to run")
parser.add_argument("--batch_size", default=64, type=int,
                    help="batch size per gpu, i.e. how many unique instances per gpu")
parser.add_argument("--base_lr", default=4.8, type=float, help="base learning rate")
parser.add_argument("--final_lr", type=float, default=0, help="final learning rate")
parser.add_argument("--wd", default=1e-6, type=float, help="weight decay")
parser.add_argument("--warmup_epochs", default=10, type=int, help="number of warmup epochs")
parser.add_argument("--start_warmup", default=0, type=float,
                    help="initial warmup learning rate")

#########################
#### dist parameters ###
#########################
parser.add_argument("--init_method", default="tcp://localhost:10001", type=str, help="""url used to set up distributed
                    training; see https://pytorch.org/docs/stable/distributed.html""")
parser.add_argument("--world_size", default=1, type=int, help="""
                    number of processes: it is set automatically and
                    should not be passed as argument""")
parser.add_argument("--rank", default=0, type=int, help="""rank of this process:
                    it is set automatically and should not be passed as argument""")
parser.add_argument("--local_rank", default=0, type=int,
                    help="this argument is not used and should be ignored")

#########################
#### other parameters ###
#########################
parser.add_argument("--arch", default="resnet50", type=str, help="architecture: resnet50, resnet50w2, swinT")
parser.add_argument("--hidden_mlp", default=2048, type=int,
                    help="hidden layer dimension in projection head")
parser.add_argument("--workers", default=10, type=int,
                    help="number of data loading workers")
parser.add_argument("--checkpoint_freq", type=int, default=25,
                    help="Save the model periodically")
parser.add_argument("--sync_bn", type=str, default="pytorch", help="synchronize bn")
parser.add_argument("--syncbn_process_group_size", type=int, default=8, help=""" see
                    https://github.com/NVIDIA/apex/blob/master/apex/parallel/__init__.py#L58-L67""")
parser.add_argument("--dump_path", type=str, default=".",
                    help="experiment dump path for checkpoints and log")
parser.add_argument("--seed", type=int, default=31, help="seed")
parser.add_argument("--checkpoint_model", default=False, action="store_true",
                    help="whether adopt checkpoint mode in forward")


def main():
    args, _ = parser.parse_known_args()
    os.makedirs(args.dump_path, exist_ok=True)
    ngpus_per_node = torch.cuda.device_count()
    mp.spawn(main_worker, nprocs=ngpus_per_node, args=(ngpus_per_node, args,))


def main_worker(gpu, ngpus_per_node, args):
    init_distributed_mode(args, ngpus_per_node, gpu)
    fix_random_seeds(args.seed)
    logger, training_stats = initialize_exp(args, "epoch", "loss")

    # build data
    train_dataset = MultiCropDataset(
        args.data_path,
        'train',
        args.size_crops,
        args.nmb_crops,
        args.min_scale_crops,
        args.max_scale_crops,
        return_index=True,
        byolAug=args.byolAug,
        size_dataset=1000
    )
    sampler = torch.utils.data.distributed.DistributedSampler(train_dataset)
    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        sampler=sampler,
        batch_size=args.batch_size,
        num_workers=args.workers,
        pin_memory=True,
        drop_last=True,
        persistent_workers=True
    )
    logger.info("Building data done with {} images loaded.".format(len(train_dataset)))

    # build model
    if args.arch != 'swinT':
        model_q = resnet_models.__dict__[args.arch](
            normalize=True,
            hidden_mlp=args.hidden_mlp,
            output_dim=args.feat_dim,
            nmb_prototypes=args.nmb_prototypes,
            with_predictor=args.with_predictor,
            checkpoint=args.checkpoint_model
        )
    else:
        model_q = SwinTransformer(img_size=args.size_crops[0],
                                  drop_path_rate=0.2,
                                  l2_norm=True,
                                  hidden_mlp=args.hidden_mlp,
                                  output_dim=args.feat_dim,
                                  nmb_prototypes=args.nmb_prototypes,
                                  with_predictor=args.with_predictor,
                                  checkpoint=args.checkpoint_model)

    model = TwoStreamNet(model_q, momentum=args.K_momentum)

    # synchronize batch norm layers
    if args.sync_bn == "pytorch":
        model = nn.SyncBatchNorm.convert_sync_batchnorm(model)
    elif args.sync_bn == "apex":
        # with apex syncbn we sync bn per group because it speeds up computation
        # compared to global syncbn
        process_group = apex.parallel.create_syncbn_process_group(args.syncbn_process_group_size)
        model = apex.parallel.convert_syncbn_model(model, process_group=process_group)
    # copy model to GPU
    model = model.cuda()
    if args.rank == 0:
        logger.info(model)
    logger.info("Building model done.")

    # build optimizer
    if args.arch != 'swinT':
        optimizer = torch.optim.SGD(
            model.q_encoder.parameters(),
            lr=args.base_lr,
            momentum=0.9,
            weight_decay=args.wd,
        )
        optimizer = LARC(optimizer=optimizer, trust_coefficient=0.001, clip=False)
    else:
        optimizer = build_opt_swinT(model.q_encoder, args)
    warmup_lr_schedule = np.linspace(args.start_warmup, args.base_lr, len(train_loader) * args.warmup_epochs)
    iters = np.arange(len(train_loader) * (args.epochs - args.warmup_epochs))
    cosine_lr_schedule = np.array([args.final_lr + 0.5 * (args.base_lr - args.final_lr) * (1 + \
                         math.cos(math.pi * t / (len(train_loader) * (args.epochs - args.warmup_epochs)))) for t in iters])
    lr_schedule = np.concatenate((warmup_lr_schedule, cosine_lr_schedule))
    logger.info("Building optimizer done.")

    # wrap model
    model = nn.parallel.DistributedDataParallel(
        model,
        device_ids=[args.gpu_to_work_on],
        find_unused_parameters=False if args.sync_bn == 'pytorch' else True,
    )

    # optionally resume from a checkpoint
    to_restore = {"epoch": 0}
    restart_from_checkpoint(
        os.path.join(args.dump_path, "checkpoint.pth.tar"),
        run_variables=to_restore,
        state_dict=model,
        optimizer=optimizer,
    )
    start_epoch = to_restore["epoch"]

    # build the feature memory bank
    mb_path = os.path.join(args.dump_path, "mb" + str(args.rank) + ".pth")
    if os.path.isfile(mb_path):
        mb_ckp = torch.load(mb_path)
        local_memory_index = mb_ckp["local_memory_index"]
        local_memory_embeddings = mb_ckp["local_memory_embeddings"]
    else:
        local_memory_index, local_memory_embeddings = init_memory(train_loader, model, args, logger)
        torch.save({"local_memory_embeddings": local_memory_embeddings,
                    "local_memory_index": local_memory_index}, mb_path)

    cudnn.benchmark = True

    # init C_momentum
    total_iters = args.epochs * len(train_loader)
    C_momentum_step = (args.C_momentum - args.C_momentum_final) / total_iters
    if args.linear_C_momentum:
        args.C_momentum = args.C_momentum - C_momentum_step * start_epoch * len(train_loader)

    # training
    for epoch in range(start_epoch, args.epochs):
        torch.cuda.empty_cache()

        # train the network for one epoch
        logger.info("============ Starting epoch %i ... ============" % epoch)

        # set sampler
        train_loader.sampler.set_epoch(epoch)

        # train the network
        scores, local_memory_index, local_memory_embeddings = train(
            train_loader,
            model,
            optimizer,
            epoch,
            lr_schedule,
            local_memory_index,
            local_memory_embeddings,
            args,
            logger,
            C_momentum_step,
        )
        training_stats.update(scores)

        # save checkpoints
        if args.rank == 0:
            save_dict = {
                "epoch": epoch + 1,
                "state_dict": model.state_dict(),
                "optimizer": optimizer.state_dict(),
            }
            torch.save(
                save_dict,
                os.path.join(args.dump_path, "checkpoint.pth.tar"),
            )
            if epoch % args.checkpoint_freq == 0 or epoch == args.epochs - 1:
                shutil.copyfile(
                    os.path.join(args.dump_path, "checkpoint.pth.tar"),
                    os.path.join(args.dump_checkpoints, "ckp-" + str(epoch) + ".pth"),
                )
        torch.save({"local_memory_embeddings": local_memory_embeddings,
                    "local_memory_index": local_memory_index}, mb_path)


def train(loader, model, optimizer, epoch, schedule, local_memory_index, local_memory_embeddings, args, logger,
          C_momentum_step):
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    model.train()
    cross_entropy = nn.CrossEntropyLoss(ignore_index=-100, reduction='sum')

    cluster_memory(args, model, local_memory_index, local_memory_embeddings, len(loader.dataset))

    # reset the k_encoder
    if args.reset_k_encoder:
        with torch.no_grad():
            for param_q, param_k in zip(model.module.q_encoder.parameters(), model.module.k_encoder.parameters()):
                param_k.data = param_q.data

    end = time.time()
    start_idx = 0

    if args.multi_forward:
        forward_batch = max(1, 4096 // (args.batch_size * torch.distributed.get_world_size()))
        logger.info('forward_batch: ' + str(forward_batch))
    else:
        forward_batch = 1
    emb_u = {}
    targets_u = {}

    for it, (idx, inputs, inputs_k) in enumerate(loader):
        # measure data loading time
        data_time.update(time.time() - end)

        # update learning rate
        iteration = epoch * len(loader) + it
        for param_group in optimizer.param_groups:
            param_group["lr"] = schedule[iteration]

        # ============ multi-res forward passes ... ============
        # change the augmentation for q and k in turn
        if it % 2 == 0:
            q = inputs
            k = inputs_k
        else:
            q = inputs_k
            k = inputs
        emb, emb_pred, emb_k, _, output, output_pred, new_assignments, _, output_aligned = model(q, inputs_k=k if args.byolAug else None,
                                                                                      update_k_encoder=it % forward_batch == 0,
                                                                                      crops_for_assign=args.crops_for_assign,
                                                                                      crops_for_q=args.crops_for_q)
        output_aligned = [o.detach() for o in output_aligned]
        bs = inputs[0].size(0)

        # ============ update centroids ... ============
        if args.linear_C_momentum:
            args.C_momentum -= C_momentum_step
        for h, K in enumerate(args.nmb_prototypes):
            j = h % len(args.crops_for_q)
            targets_ = output_aligned[h].max(dim=1)[1]

            if it % forward_batch == 0:
                targets_u[h] = targets_[bs * j: bs * (j + 1)]
                emb_u[h] = emb[bs * j: bs * (j + 1)]
            else:
                targets_u[h] = torch.cat((targets_u[h].detach(), targets_[bs * j: bs * (j + 1)]), dim=0)
                emb_u[h] = torch.cat((emb_u[h].detach(), emb[bs * j: bs * (j + 1)]), dim=0)
            if it % forward_batch == forward_batch - 1:
                centroids = getattr(model.module.k_encoder.prototypes, "prototypes" + str(h)).detach()
                centroids = M_step(args, emb_u[h], targets_u[h].detach(), centroids, K, momentum=args.C_momentum)
                setattr(model.module.k_encoder.prototypes, "prototypes" + str(h), centroids)
                setattr(model.module.q_encoder.prototypes, "prototypes" + str(h), centroids)
        output = model.module.q_encoder.prototypes(emb)
        output_pred = model.module.q_encoder.prototypes(emb_pred)

        # ============ SMoG loss ... ============
        loss = 0
        n_samples = 0
        for h in range(len(args.nmb_prototypes)):
            scores = (output[h] if not args.with_predictor else output_pred[h]) / args.temperature
            targets = new_assignments[h].max(dim=1)[1]
            for i, crop_id in enumerate(args.crops_for_assign):
                subscores = scores
                subtargets = targets[bs * i: bs * (i + 1)].repeat(len(subscores) // bs).detach()
                loss += cross_entropy(subscores, subtargets)
                n_samples += subtargets.size(0)
        loss = loss / n_samples

        # ============ backward and optim step ... ============
        loss.backward()
        if it % forward_batch == forward_batch - 1:
            for p in model.parameters():
                if p.grad is not None:
                    p.grad /= forward_batch
            if args.arch == 'swinT':
                torch.nn.utils.clip_grad_norm_(model.parameters(), 3.0)
            # cancel some gradients
            for name, p in model.named_parameters():
                if "prototypes" in name:
                    p.grad = None
            optimizer.step()
            optimizer.zero_grad()

        # ============ update memory banks ... ============
        local_memory_index[start_idx: start_idx + bs] = idx
        for i, crop_idx in enumerate(args.crops_for_q):
            local_memory_embeddings[i][start_idx: start_idx + bs] = \
                emb[i * bs: (i + 1) * bs].detach()
        start_idx += bs

        # ============ misc ... ============
        losses.update(loss.item(), inputs[0].size(0))
        batch_time.update(time.time() - end)
        end = time.time()
        if it % 50 == 0:
            logger.info(
                "Epoch: [{0}][{1}]\t"
                "Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t"
                "Data {data_time.val:.3f} ({data_time.avg:.3f})\t"
                "Loss {loss.val:.4f} ({loss.avg:.4f})\t"
                "Lr: {lr:.4f}\t"
                "C_momentum: {c_momentum:.4f}\t"
                "K_momentum: {k_momentum:.4f}\t"
                "WD: {wd:.4f}".format(
                    epoch,
                    it,
                    batch_time=batch_time,
                    data_time=data_time,
                    loss=losses,
                    lr=optimizer.optim.param_groups[0]["lr"] if args.arch != 'swinT' else optimizer.param_groups[0]["lr"],
                    c_momentum=args.C_momentum,
                    k_momentum=model.module.m,
                    wd=optimizer.optim.param_groups[0]["weight_decay"] if args.arch != 'swinT' else optimizer.param_groups[0]["weight_decay"]
                )
            )
    return (epoch, losses.avg), local_memory_index, local_memory_embeddings


def init_memory(dataloader, model, args, logger):
    size_memory_per_process = len(dataloader) * args.batch_size
    local_memory_index = torch.zeros(size_memory_per_process).long().cuda()
    local_memory_embeddings = torch.zeros(len(args.crops_for_q), size_memory_per_process, args.feat_dim).cuda()
    start_idx = 0
    with torch.no_grad():
        logger.info('Start initializing the memory banks')
        loader = tqdm(dataloader) if args.rank % torch.cuda.device_count() == 0 is not None else dataloader
        for index, inputs, _ in loader:
            nmb_unique_idx = inputs[0].size(0)
            index = index.cuda(non_blocking=True)

            # get embeddings
            outputs = []
            for crop_idx in args.crops_for_q:
                inp = inputs[crop_idx].cuda(non_blocking=True)
                outputs.append(model(inp, with_k=False, crops_for_q=[0])[0])

            # fill the memory bank
            local_memory_index[start_idx : start_idx + nmb_unique_idx] = index
            for mb_idx, embeddings in enumerate(outputs):
                local_memory_embeddings[mb_idx][
                    start_idx: start_idx + nmb_unique_idx
                ] = embeddings
            start_idx += nmb_unique_idx
    logger.info('Initializion of the memory banks done.')
    return local_memory_index, local_memory_embeddings


def update_assignment(assignments, new_assign, local_index):
    # gather the updated assign
    new_assign_all = concat_all_gather(new_assign).cpu()

    # gather the index
    index_all = concat_all_gather(local_index.cuda()).cpu()

    assignments[index_all] = new_assign_all

    return assignments, new_assign_all


def M_step(args, features, assignments, centroids, K, momentum=0.0):
    # where_helper = get_indices_sparse(assignments.cpu().numpy())
    where_helper = get_indices_cuda(assignments)
    counts = torch.zeros(K).cuda(non_blocking=True).int()
    emb_sums = torch.zeros(K, args.feat_dim).cuda(non_blocking=True)
    for k in range(len(where_helper)):
        if len(where_helper[k]) > 0:
            emb_sums[k] = torch.sum(
                features[where_helper[k]],
                dim=0,
            )
            counts[k] = len(where_helper[k])
    dist.all_reduce(counts)
    mask = counts > 0
    dist.all_reduce(emb_sums)
    emb_sums = emb_sums + centroids * ~mask.unsqueeze(1)
    counts = counts + ~mask
    centroids = momentum * centroids + (1-momentum) * emb_sums / counts.unsqueeze(1)

    # normalize centroids
    centroids = nn.functional.normalize(centroids, dim=1, p=2)
    return centroids


def cluster_memory(args, model, local_memory_index, local_memory_embeddings, size_dataset, nmb_kmeans_iters=10):
    j = 0
    assignments = -100 * torch.ones(len(args.nmb_prototypes), size_dataset).long()
    with torch.no_grad():
        for i_K, K in enumerate(args.nmb_prototypes):
            # run distributed k-means

            # init centroids with elements from memory bank of rank 0
            centroids = torch.empty(K, args.feat_dim).cuda(non_blocking=True)
            if args.rank == 0:
                random_idx = torch.randperm(len(local_memory_embeddings[j]))[:K]
                assert len(random_idx) >= K, "please reduce the number of centroids"
                centroids = local_memory_embeddings[j][random_idx]
            dist.broadcast(centroids, 0)

            for n_iter in range(nmb_kmeans_iters + 1):

                # E step
                dot_products = torch.mm(local_memory_embeddings[j], centroids.t())
                _, local_assignments = dot_products.max(dim=1)

                # finish
                if n_iter == nmb_kmeans_iters:
                    break

                # M step
                centroids = M_step(args, local_memory_embeddings[j], local_assignments, centroids, K)

            setattr(model.module.k_encoder.prototypes, "prototypes" + str(i_K), centroids)
            setattr(model.module.q_encoder.prototypes, "prototypes" + str(i_K), centroids)

            assignments[i_K], _ = update_assignment(assignments[i_K], local_assignments, local_memory_index)

            # next memory bank to use
            j = (j + 1) % len(args.crops_for_q)

    return assignments


def get_indices_sparse(data):
    cols = np.arange(data.size)
    M = csr_matrix((cols, (data.ravel(), cols)), shape=(int(data.max()) + 1, data.size))
    return [np.unravel_index(row.data, data.shape) for row in M]


def get_indices_cuda(data):
    assert len(data.size()) == 1, 'only support 1D tensor'
    flatten_data_org = data
    flatten_data = torch.cat((flatten_data_org, torch.arange(int(data.max()) + 1, device=data.device)), dim=0)
    cols = torch.arange(flatten_data.size(0), device=data.device)
    M = torch.sparse_coo_tensor(indices=torch.stack((flatten_data, cols), 0),
                                values=cols,
                                size=(int(data.max()) + 1, flatten_data.size(0)))
    M = M.coalesce()
    inds = torch.unique_consecutive(M.indices()[0],return_counts=True,)[1] - 1

    cols = torch.arange(flatten_data_org.size(0), device=data.device)
    M = torch.sparse_coo_tensor(indices=torch.stack((flatten_data_org, cols), 0),
                                values=cols,
                                size=(int(data.max()) + 1, flatten_data_org.size(0)))
    M = M.coalesce()
    values = M.values()

    res = torch.split(values, inds.cpu().numpy().tolist())

    return res


if __name__ == "__main__":
    main()

