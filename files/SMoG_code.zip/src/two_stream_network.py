import torch
import torch.nn as nn
from src.SwinTrans_multicrop import SwinTransformer, DropPath
import copy


class TwoStreamNet(nn.Module):
    def __init__(self, base_model, momentum=0.99):
        super(TwoStreamNet, self).__init__()
        self.q_encoder = base_model
        self.k_encoder = copy.deepcopy(self.q_encoder)
        self.k_encoder.predictor_head = None
        self.m = momentum

        for m in self.k_encoder.modules():
            if isinstance(m, DropPath):
                m.drop_prob = 0.0

        for param_k in self.k_encoder.parameters():
            param_k.requires_grad = False  # not update by gradient

    def forward_q(self, inputs):
        return self.q_encoder(inputs)

    @torch.no_grad()
    def forward_k(self, inputs):
        return self.k_encoder(inputs)

    def forward(self, inputs, inputs_k=None, with_k=True, update_k_encoder=True, crops_for_assign=[0, 1], crops_for_q=[2, 3]):
        if with_k and update_k_encoder:
            self._momentum_update_key_encoder()

        # q_stream: get emb and output
        if not isinstance(inputs, list):
            inputs = [inputs]
        q = inputs[crops_for_q[0]:]

        out_q = self.forward_q(q)
        if len(out_q) == 4:
            emb_q, emb_q_pred, output, output_pred = out_q
        else:
            emb_q, emb_q_pred = out_q
            output = None
            output_pred = None

        # recalculate emb_q when: 1) adopt different dropPath;
        output_aligned = output
        if isinstance(self.q_encoder, SwinTransformer):
            q = [inputs[i] for i in crops_for_q]
            for m in self.q_encoder.modules():
                if isinstance(m, DropPath):
                    m.eval()
            with torch.no_grad():
                emb_q, _, output_aligned, _ = self.forward_q(q)
            self.q_encoder.train()

        # k_stream: get assignments
        if with_k:
            if inputs_k is not None:
                inputs = inputs_k
            # out_k = self.forward_k([inputs[i] for i in crops_for_assign])
            out_k = self.forward_k([inputs[i] for i in crops_for_assign] + inputs[crops_for_q[-1]+1:])
            if len(out_q) == 4:
                emb_k, emb_k_pred, assignments, assignments_pred = out_k
            else:
                emb_k, emb_k_pred = out_k
                assignments = None
                assignments_pred = None
        else:
            emb_k = None
            emb_k_pred = None
            assignments = None
            assignments_pred = None
        return emb_q, emb_q_pred, emb_k, emb_k_pred, \
               output, output_pred, assignments, assignments_pred, output_aligned

    @torch.no_grad()
    def _momentum_update_key_encoder(self):
        for (q_name, param_q), (_, param_k) in zip(self.q_encoder.named_parameters(), self.k_encoder.named_parameters()):
            if 'prototypes' not in q_name:
                param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)
