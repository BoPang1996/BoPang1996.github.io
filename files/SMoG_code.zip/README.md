# Unsupervised Visual Representation Learning by Synchronous Momentum Grouping
This code provides a PyTorch implementation and pretrained models for **SMoG** (**S**ynchronous **Mo**mentum **G**rouping), as described in the paper [Unsupervised Visual Representation Learning by Synchronous Momentum Grouping](https://arxiv.org/abs/2207.06167).

SMoG is an efficient unsupervised visual representation learning method for both CNN and Transformers. It inherits the advantages of contrastive learning and
clustering-based unsupervised method. By directly contrasting the group features and allowing gradients back-propagating through group features, SMoG achieves better performance than vanilla supervised learning.

# Models

Here, we provide the pretrained weights.

| backbone | epochs | batch-size | multi-crop | ImageNet top-1 acc. | url | config | log | linear log|
|-------------------|-------------------|---------------------|--------------------|--------------------|--------------------|--------------------|--------------------|--------------------|
| ResNet50 | 400 | 4096 | 2x224 + 4x96 | 76.6 | [model]() | [script](./scripts/pretrain/SMoG_ResNet50_400ep_2x224_4x96.sh) | [log]() | [linear_log]()
| ResNet50w2 | 400 | 4096 | 2x224 + 4x96 | 78.3 | [model]() | [script](./scripts/pretrain/SMoG_ResNet50w2_400ep_2x224_4x96.sh) | [log]() | [linear_log]()
| Swin-T | 400 | 4096 | 2x224 + 4x96 | 77.5 | [model]() | [script](./scripts/pretrain/SMoG_SwinT_400ep_2x224_4x96.sh) | [log]() | [linear_log]()


# Running SMoG Pre-training

## Requirements
- Python 3
- [PyTorch](http://pytorch.org) install >= 1.4.0
- torchvision
- CUDA 10.1, 10.2, 11.3
- [Apex](https://github.com/NVIDIA/apex) with CUDA extension
- Other dependencies: scipy, pandas, numpy, timm, tensorboardX

## Training and evaluation scripts
We provide the training scripts in [scripts folder](./scripts), just run:
```
bash ./scripts/SMoG_ResNet50_400ep_2x224_4x96.sh
```

To train with multinode, you meight need to set up `init_method` parameter. We refer the user to pytorch distributed documentation ([env](https://pytorch.org/docs/stable/distributed.html#environment-variable-initialization) or [file](https://pytorch.org/docs/stable/distributed.html#shared-file-system-initialization) or [tcp](https://pytorch.org/docs/stable/distributed.html#tcp-initialization)) for setting the distributed initialization method (parameter `dist_url`) correctly.

The linear test script is also provided in [scripts folder](./scripts). The detailed evaluation parameter is provided in the bottom of the pre-train script. You might need to modify them in the linear script.

## Acknowledgement
The code is based on the official pytorch implementation of [SwAV](https://github.com/facebookresearch/swav).
## Citation
If you find this repository useful in your research, please cite:
```
@inproceedings{pang2022smog,
  title={Unsupervised Visual Representation Learning by Synchronous Momentum Grouping},
  author={Pang, Bo and Zhang, Yifan and Li, Yaoyi and Cai, Jia and Lu, Cewu},
  booktitle={ECCV}
  year={2022}
}
```
