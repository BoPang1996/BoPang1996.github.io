python main_SMoG.py \
--data_path <data path to ImageNet> \
--num_crops 3 4
--size_crops 224 96 \
--min_scale_crops 0.2 0.05 \
--max_scale_crops 1.0 0.2 \
--crops_for_assign 0 \
--crops_for_q 1 2 \
--temperature 0.1 \
--nmb_prototypes 3000 3000 3000 \
--epochs 400 \
--batch_size 64 \
--base_lr 0.001 \
--final_lr 0.00004 \
--wd 0.05 \
--warmup_epochs 10 \
--start_warmup 0.00004 \
--arch swinT \
--sync_bn apex \
--syncbn_process_group_size 8 \
--K_momentum 0.999 \
--reset_k_encoder \
--C_momentum 1.0 \
--C_momentum_final 0.99 \
--linear_C_momentum \
--byolAug \
--with_predictor \
--hidden_mlp 2048 \
--feat_dim 256 \
--multi-forward \
--dump_path <path to save log & checkpoint>

# linear param
# lr: 0.1
# WD: 0.0
# epochs: 150