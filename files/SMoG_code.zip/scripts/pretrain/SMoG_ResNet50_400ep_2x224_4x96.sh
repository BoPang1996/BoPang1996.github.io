python main_SMoG.py \
--data_path <data path to ImageNet> \
--num_crops 4 4 \
--size_crops 224 96 \
--min_scale_crops 0.2 0.05 \
--max_scale_crops 1.0 0.2 \
--crops_for_assign 0 1 \
--crops_for_q 2 3 \
--temperature 0.1 \
--nmb_prototypes 3000 3000 3000 \
--epochs 400 \
--batch_size 64 \
--base_lr 4.8 \
--final_lr 0.0048 \
--wd 1e-6 \
--warmup_epochs 10 \
--start_warmup 0.01 \
--arch resnet50 \
--sync_bn apex \
--syncbn_process_group_size 8 \
--K_momentum 0.999 \
--reset_k_encoder \
--C_momentum 1.0 \
--C_momentum_final 0.99 \
--linear_C_momentum \
--byolAug \
--with_predictor \
--hidden_mlp 2048 \
--feat_dim 128 \
--multi-forward \
--dump_path <path to save log & checkpoint>


# linear param
# lr: 0.3
# WD: 1e-6
