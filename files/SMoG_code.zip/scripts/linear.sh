python eval_linear.py \
--dump_path <path to save logs and models>
--data_path <path to ImageNet>
--arch <resnet50, resnet50w2, or swinT>
--pretrained <path to pre-trained checkpoint>
--epochs 100
--lr 0.3
--wd 1e-6